READ ME

Project Name:
112 World Cup Simulator
-The World Cup Simulator allows you to choose a national team and play a soccer match against an AI

How to run:
Before running the code, make sure you are connected to the internet as images are linked as URLs and cannot be accessed otherwise

Controls:
WASD to move
J to pass
K to start shot, K again to time shot and actually shoot
; to switch players
Left and Right arrow keys + Enter to select a team

Shortcuts:
While in game, escape will restart the app from the team selection screen
backspace will reset the players to their initial locations
